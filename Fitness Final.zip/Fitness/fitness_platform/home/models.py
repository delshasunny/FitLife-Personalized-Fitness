from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Signup(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15, unique=True)
    password = models.CharField(max_length=100)



    def save(self, *args, **kwargs):
        from django.contrib.auth.hashers import make_password
        self.password = make_password(self.password)  # Hashing password
        super().save(*args, **kwargs)

    def __str__(self):
        return self.email





class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    # Step 1: Personal Information
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')])

    # Step 2: Physical Attributes
    height = models.FloatField(null=True, blank=True)  # in cm
    weight = models.FloatField(null=True, blank=True)  # in kg

    # Step 3: Fitness Goals
    primary_goal = models.CharField(max_length=30, choices=[
        ('Weight Loss', 'Weight Loss'),
        ('Muscle Gain', 'Muscle Gain'),
        ('Flexibility', 'Flexibility'),
        ('Endurance', 'Endurance'),
        ('General Fitness', 'General Fitness')
    ])
    target_weight = models.FloatField(null=True, blank=True)
    workout_frequency_goal = models.CharField(max_length=50)

    # Step 4: Activity Level
    activity_level = models.CharField(max_length=20, choices=[
        ('Sedentary', 'Sedentary'),
        ('Lightly Active', 'Lightly Active'),
        ('Moderately Active', 'Moderately Active'),
        ('Very Active', 'Very Active')
    ])

    # Step 5: Workout Preferences
    preferred_workout_type = models.CharField(max_length=50)
    preferred_workout_duration = models.CharField(max_length=20)
    preferred_workout_intensity = models.CharField(max_length=20)
    home_or_gym = models.CharField(max_length=10)

    # Step 6: Experience and Injury
    experience_level = models.CharField(max_length=20)
    past_injuries = models.TextField(blank=True, null=True)

    profile_completed = models.BooleanField(default=False)

    def __str__(self):
        return self.user.username

class DailyWorkout(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    workout_name = models.CharField(max_length=100)
    time_spent = models.PositiveIntegerField(help_text="Time in minutes")

    def __str__(self):
        return f"{self.user.username} - {self.workout_name} on {self.date}"


