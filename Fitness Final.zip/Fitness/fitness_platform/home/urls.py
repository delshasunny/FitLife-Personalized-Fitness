from django.urls import path
from .import views
urlpatterns = [
    path('',views.index,name='index'),
    path('login/',views.loginn,name='loginn'),
    path('register/',views.signup_view,name='signup'),
    # path('base/',views.base,name='base'),
    path('dashboard/',views.profile,name='dashboard'),
    path('logout/',views.log_out,name='logout'),
    path('about/', views.about_us, name='aboutus'),
    path('contact/',views.contact_static, name='contact'),
    path('profile/',views.profile,name='profile'),
    path('profile/step1/', views.profile_step1, name='profile_step1'),
    path('profile/step2/', views.profile_step2, name='profile_step2'),
    path('profile/step3/', views.profile_step3, name='profile_step3'),
    path('profile/step4/', views.profile_step4, name='profile_step4'),
    path('profile/step5/', views.profile_step5, name='profile_step5'),
    path('profile/step6/', views.profile_step6, name='profile_step6'),
    path('profile/daily_workout_view/', views.daily_workout_view, name='daily_workout_view'),
    path('profile/workout_videos', views.workout_videos, name='workout_videos'),
    
]