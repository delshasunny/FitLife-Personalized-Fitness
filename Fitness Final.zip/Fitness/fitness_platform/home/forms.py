from django import forms
from .models import DailyWorkout

class DailyWorkoutForm(forms.ModelForm):
    class Meta:
        model = DailyWorkout
        fields = ['workout_name', 'time_spent']
        widgets = {
            'workout_name': forms.TextInput(attrs={'class': 'form-control'}),
            'time_spent': forms.NumberInput(attrs={'class': 'form-control'}),
        }
