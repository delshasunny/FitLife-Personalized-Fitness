from django.contrib import admin

# Register your models here.

from.models import Signup
admin.site.register(Signup)
# home/admin.py
from .models import UserProfile
admin.site.register(UserProfile)
