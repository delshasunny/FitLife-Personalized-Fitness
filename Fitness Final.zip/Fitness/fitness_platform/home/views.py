from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.views.decorators.cache import never_cache
from django.http import HttpResponse
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt

from .models import Signup, UserProfile
from .models import DailyWorkout
from .forms import DailyWorkoutForm
from datetime import date
import re

@never_cache
def index(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'index.html')

# def base(request):
#     return render(request, "base.html")

@csrf_exempt
def signup_view(request):
    if request.method == "POST":
        first_name = request.POST.get('firstname')
        last_name = request.POST.get('lastname')
        email = request.POST.get('email')
        phone = request.POST.get('phoneno')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return redirect('signup')
        if len(password) < 6:
            messages.error(request, "Password must be at least 8 characters long!")
            return redirect('signup')
        if not re.match(r'^\d{10}$', phone):
            messages.error(request, "Phone number must contain exactly 10 digits.")
            return redirect('signup')

        if User.objects.filter(username=email).exists():
            messages.error(request, "Email already registered!")
            return redirect('signup')

        user = User.objects.create_user(username=email, email=email, password=password)
        user.first_name = first_name
        user.last_name = last_name
        user.save()

        signup = Signup(first_name=first_name, last_name=last_name, email=email, phone=phone, password=password)
        signup.save()

        messages.success(request, "Registration successful! Please log in.")
        return redirect('loginn')

    return render(request, "signup.html")

@csrf_exempt
@never_cache
def loginn(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = authenticate(request, username=email, password=password)

        if user is not None:
            login(request, user)
            # Check if profile exists
            if not UserProfile.objects.filter(user=user, profile_completed=True).exists():
                    return redirect('profile_step1')

            return redirect('dashboard')
        else:
            messages.error(request, "Invalid credentials! Try again.")
            return redirect('loginn')

    return render(request, "login.html")

@login_required(login_url='loginn')
@never_cache
def dashboard(request):
    profile = UserProfile.objects.filter(user=request.user).first()
    if not profile or not profile.profile_completed:
        return redirect('profile_step1')
    return render(request, "dashboard.html")


@never_cache
def log_out(request):
    logout(request)
    response = redirect('loginn')
    response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response['Pragma'] = 'no-cache'
    response['Expires'] = '0'
    messages.success(request, "You have been logged out successfully.")
    return response

# @login_required(login_url='loginn')
# @never_cache
# def profile(request):
    
#     print("Profile view accessed")  
    
#     # print("Profile view accessed") 
#     profile = UserProfile.objects.filter(user=request.user).first()
    
#     print(f"Profile: {profile}")  # Debugging line
#     if not profile:
#         return redirect('profile_step1')
#     return render(request, "profile.html", {'profile': profile})


@login_required(login_url='loginn')
@never_cache
def profile(request):
    profile = UserProfile.objects.filter(user=request.user).first()

    if not profile or not profile.profile_completed:
        return redirect('profile_step1')

    print(f"Profile view accessed for user {request.user.first_name}")
    print(f"Profile for user {request.user.first_name}, Workout Frequency Goal: {profile.workout_frequency_goal}")

    return render(request, "profile.html", {'profile': profile, 'first_name': request.user.first_name})



# Multi-step profile completion views

@login_required
def profile_step1(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)

    if profile.profile_completed:
        return redirect('dashboard')  # If already done, go to dashboard

    if request.method == 'POST':
        profile.date_of_birth = request.POST.get('date_of_birth')
        profile.gender = request.POST.get('gender')
        profile.save()
        return redirect('profile_step2')
        if date_of_birth:
            # Extract the year from the selected date of birth
            selected_year = int(date_of_birth.split('-')[0])

            # Ensure the selected year is between 1920 and 2021
            if selected_year > 2021:
                messages.error(request, "Please select a valid year of birth. You cannot select a year after 2021.")
                return redirect('profile_step1')
            if selected_year == 2025:  # Check if the selected year is 2025 (this year)
                messages.error(request, "You cannot select this year. Please choose a valid year.")
                return redirect('profile_step1')

    return render(request, 'profile_steps/step1.html')


@login_required
def profile_step2(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)  # ✅ Fix: unpack both
    if request.method == 'POST':
        profile.height = request.POST.get('height')
        profile.weight = request.POST.get('weight')
        profile.save()
        return redirect('profile_step3')
    return render(request, 'profile_steps/step2.html')


@login_required
def profile_step3(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)  # ✅ Fix: unpack both values
    if request.method == 'POST':
        profile.primary_goal = request.POST.get('primary_goal')
        profile.target_weight = request.POST.get('target_weight')
        profile.workout_frequency_goal = request.POST.get('workout_frequency_goal')
        profile.save()
        return redirect('profile_step4')
    return render(request, 'profile_steps/step3.html')


@login_required
def profile_step4(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)  # ✅ Fix: unpack both values
    if request.method == 'POST':
        profile.activity_level = request.POST.get('activity_level')
        profile.save()
        return redirect('profile_step5')
    return render(request, 'profile_steps/step4.html')


@login_required
def profile_step5(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)  # ✅ fix here
    if request.method == 'POST':
        profile.preferred_workout_type = request.POST.get('preferred_workout_type')
        profile.preferred_workout_duration = request.POST.get('preferred_workout_duration')
        profile.preferred_workout_intensity = request.POST.get('preferred_workout_intensity')
        profile.home_or_gym = request.POST.get('home_or_gym')
        profile.save()
        return redirect('profile_step6')
    return render(request, 'profile_steps/step5.html')



@login_required
def profile_step6(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)  # ✅ unpack properly
    if request.method == 'POST':
        profile.experience_level = request.POST.get('experience_level')
        profile.past_injuries = request.POST.get('past_injuries')
        profile.profile_completed = True
        profile.save()
        messages.success(request, "Profile completed successfully!")
        return redirect('dashboard')
    return render(request, 'profile_steps/step6.html')


@login_required
def daily_workout_view(request):
    # Get today's workout if exists
    todays_workout = DailyWorkout.objects.filter(user=request.user, date=date.today()).first()
    
    if request.method == 'POST':
        form = DailyWorkoutForm(request.POST)
        if form.is_valid():
            workout = form.save(commit=False)
            workout.user = request.user
            workout.save()
            return redirect('daily_workout_view')
    else:
        form = DailyWorkoutForm()

    # History - Order by date (oldest first)
    history = DailyWorkout.objects.filter(user=request.user).order_by('date')  # Changed to ascending order

    return render(request, 'daily_workout.html', {
        'form': form,
        'todays_workout': todays_workout,
        'history': history
    })


    
    
@login_required
def workout_videos(request):
    # Get today's workout if exists
    todays_workout = DailyWorkout.objects.filter(user=request.user, date=date.today()).first()

    if request.method == 'POST':
        form = DailyWorkoutForm(request.POST)
        if form.is_valid():
            workout = form.save(commit=False)
            workout.user = request.user
            workout.save()
            return redirect('daily_workout_view')  # Redirect to the daily workout view page
    else:
        form = DailyWorkoutForm()

    # History
    history = DailyWorkout.objects.filter(user=request.user).order_by('-date')

    return render(request, 'workout_videos.html', {
        'form': form,
        'todays_workout': todays_workout,
        'history': history
    })



def about_us(request):
    return render(request, 'about.html')
def contact_static(request):
    return render(request, 'contact.html')
